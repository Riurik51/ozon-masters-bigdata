#!/bin/bash

projects/1/train.py $@
